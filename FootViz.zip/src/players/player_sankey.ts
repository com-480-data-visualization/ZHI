const COLORS = ["#e0ac2b", "green", "#6689c6", "#9a6fb0", "#a53253", "#b3253", "#c53253", "#d53253", "yellow"];

export const colors = {
  "Bundesliga": COLORS[0],
  "Championship": COLORS[1],
  "Liga Professional": COLORS[2],
  "Liga": COLORS[3],
  "Major League": COLORS[4],
  "Sup Lig": COLORS[5],
  "Premier League": COLORS[6],
  "Serie": COLORS[7],
  "others": COLORS[8],  
}
export const players = {
    nodes: [
      {
        "name": "2. Bundesliga (early)",
        "category": "Bundesliga", 
        "id": 0
      },
  
      {
        "name": "Bundesliga (early)",
        "category": "Bundesliga", 
        "id": 1
      },
  
      {
        "name": "Bundesliga (late)",
        "category": "Bundesliga", 
        "id": 2
      },
  
      {
        "name": "Bundesliga (mid)",
        "category": "Bundesliga", 
        "id": 3
      },
  
      {
        "name": "Championship (early)",
        "category": "Championship", 
        "id": 4

      },
  
      {
        "name": "Championship (late)",
        "category": "Championship", 
        "id": 5

      },
  
      {
        "name": "Championship (mid)",
        "category": "Championship", 
        "id": 6
      },
  
      {
        "name": "La Liga 2 (early)",
        "category": "Liga", 
        "id": 7
      },
  
      {
        "name": "La Liga (early)",
        "category": "Liga", 
        "id": 8
      },
  
      {
        "name": "La Liga (late)",
        "category": "Liga", 
        "id": 9
      },
  
      {
        "name": "La Liga (mid)",
        "category": "Liga", 
        "id": 10
      },
  
      {
        "name": "Liga Profesional (early)",
        "category": "Liga Profesional", 
        "id": 11
      },
  
      {
        "name": "Liga Profesional (late)",
        "category": "Liga Profesional", 
        "id": 12
      },
  
      {
        "name": "Liga Profesional (mid)",
        "category": "Liga Profesional", 
        "id": 13
      },
  
      {
        "name": "Ligue 1 (early)",
        "category": "Ligue", 
        "id": 14
      },
  
      {
        "name": "Ligue 1 (late)",
        "category": "Ligue", 
        "id": 15
      },
  
      {
        "name": "Ligue 1 (mid)",
        "category": "Ligue", 
        "id": 16
      },
  
      {
        "name": "Major League Soccer (late)",
        "category": "Major League",
         "id": 17
      },
  
      {
        "name": "Major League Soccer (mid)",
        "category": "Major League", 
        "id": 18
      },
  
      {
        "name": "Premier League (early)",
        "category": "Premier League", 
        "id": 19
      },
  
      {
        "name": "Premier League (late)",
        "category": "Premier League", 
        "id": 20
      },
  
      {
        "name": "Premier League (mid)",
        "category": "Premier League", 
        "id": 21
      },
  
      {
        "name": "Serie A (early)",
        "category": "Serie", 
        "id": 22
      },
  
      {
        "name": "Serie A (late)",
        "category": "Serie", 
        "id": 23
      },
  
      {
        "name": "Serie A (mid)",
        "category": "Serie", 
        "id": 24
      },
  
      {
        "name": "Super Lig (late)",
        "category": "Super Lig", 
        "id": 25
      },
  
      {
        "name": "Super Lig (mid)",
        "category": "Super Lig", 
        "id": 26
      },
  
      {
        "name": "others (early)",
        "category": "others", 
        "id": 27
      },
  
      {
        "name": "others (late)",
        "category": "others", 
        "id": 28
      },
  
      {
        "name": "others (mid)",
        "category": "others", 
        "id": 29
      }
    ],
    links: [
      {
        "source": 0,
        "target": 29,
        "value": 12
      },
  
      {
        "source": 29,
        "target": 28,
        "value": 121
      },
  
      {
        "source": 29,
        "target": 2,
        "value": 3
      },
  
      {
        "source": 0,
        "target": 3,
        "value": 9
      },
  
      {
        "source": 3,
        "target": 28,
        "value": 10
      },
  
      {
        "source": 3,
        "target": 2,
        "value": 31
      },
  
      {
        "source": 3,
        "target": 17,
        "value": 1
      },
  
      {
        "source": 0,
        "target": 6,
        "value": 1
      },
  
      {
        "source": 6,
        "target": 28,
        "value": 11
      },
  
      {
        "source": 0,
        "target": 18,
        "value": 3
      },
  
      {
        "source": 18,
        "target": 28,
        "value": 3
      },
  
      {
        "source": 18,
        "target": 17,
        "value": 23
      },
  
      {
        "source": 0,
        "target": 21,
        "value": 2
      },
  
      {
        "source": 21,
        "target": 20,
        "value": 36
      },
  
      {
        "source": 27,
        "target": 29,
        "value": 98
      },
  
      {
        "source": 27,
        "target": 21,
        "value": 9
      },
  
      {
        "source": 21,
        "target": 28,
        "value": 6
      },
  
      {
        "source": 29,
        "target": 17,
        "value": 3
      },
  
      {
        "source": 29,
        "target": 20,
        "value": 1
      },
  
      {
        "source": 1,
        "target": 29,
        "value": 7
      },
  
      {
        "source": 1,
        "target": 3,
        "value": 34
      },
  
      {
        "source": 3,
        "target": 20,
        "value": 1
      },
  
      {
        "source": 3,
        "target": 23,
        "value": 1
      },
  
      {
        "source": 3,
        "target": 25,
        "value": 3
      },
  
      {
        "source": 1,
        "target": 10,
        "value": 1
      },
  
      {
        "source": 10,
        "target": 9,
        "value": 30
      },
  
      {
        "source": 1,
        "target": 16,
        "value": 2
      },
  
      {
        "source": 16,
        "target": 9,
        "value": 3
      },
  
      {
        "source": 16,
        "target": 28,
        "value": 12
      },
  
      {
        "source": 1,
        "target": 21,
        "value": 2
      },
  
      {
        "source": 1,
        "target": 24,
        "value": 2
      },
  
      {
        "source": 24,
        "target": 23,
        "value": 23
      },
  
      {
        "source": 24,
        "target": 25,
        "value": 3
      },
  
      {
        "source": 29,
        "target": 23,
        "value": 4
      },
  
      {
        "source": 1,
        "target": 26,
        "value": 2
      },
  
      {
        "source": 26,
        "target": 28,
        "value": 4
      },
  
      {
        "source": 26,
        "target": 25,
        "value": 11
      },
  
      {
        "source": 4,
        "target": 6,
        "value": 19
      },
  
      {
        "source": 6,
        "target": 5,
        "value": 27
      },
  
      {
        "source": 6,
        "target": 20,
        "value": 6
      },
  
      {
        "source": 4,
        "target": 29,
        "value": 2
      },
  
      {
        "source": 4,
        "target": 10,
        "value": 1
      },
  
      {
        "source": 4,
        "target": 18,
        "value": 1
      },
  
      {
        "source": 4,
        "target": 21,
        "value": 8
      },
  
      {
        "source": 21,
        "target": 5,
        "value": 11
      },
  
      {
        "source": 4,
        "target": 24,
        "value": 1
      },
  
      {
        "source": 27,
        "target": 6,
        "value": 15
      },
  
      {
        "source": 6,
        "target": 2,
        "value": 1
      },
  
      {
        "source": 29,
        "target": 25,
        "value": 4
      },
  
      {
        "source": 27,
        "target": 18,
        "value": 20
      },
  
      {
        "source": 21,
        "target": 23,
        "value": 4
      },
  
      {
        "source": 27,
        "target": 24,
        "value": 7
      },
  
      {
        "source": 29,
        "target": 15,
        "value": 4
      },
  
      {
        "source": 27,
        "target": 16,
        "value": 10
      },
  
      {
        "source": 16,
        "target": 15,
        "value": 14
      },
  
      {
        "source": 7,
        "target": 29,
        "value": 12
      },
  
      {
        "source": 29,
        "target": 9,
        "value": 8
      },
  
      {
        "source": 7,
        "target": 10,
        "value": 11
      },
  
      {
        "source": 10,
        "target": 28,
        "value": 13
      },
  
      {
        "source": 7,
        "target": 21,
        "value": 1
      },
  
      {
        "source": 21,
        "target": 9,
        "value": 4
      },
  
      {
        "source": 8,
        "target": 29,
        "value": 6
      },
  
      {
        "source": 8,
        "target": 10,
        "value": 26
      },
  
      {
        "source": 10,
        "target": 5,
        "value": 1
      },
  
      {
        "source": 10,
        "target": 20,
        "value": 3
      },
  
      {
        "source": 10,
        "target": 25,
        "value": 1
      },
  
      {
        "source": 8,
        "target": 13,
        "value": 1
      },
  
      {
        "source": 13,
        "target": 12,
        "value": 16
      },
  
      {
        "source": 8,
        "target": 16,
        "value": 1
      },
  
      {
        "source": 8,
        "target": 18,
        "value": 1
      },
  
      {
        "source": 8,
        "target": 21,
        "value": 2
      },
  
      {
        "source": 29,
        "target": 5,
        "value": 4
      },
  
      {
        "source": 27,
        "target": 13,
        "value": 3
      },
  
      {
        "source": 27,
        "target": 10,
        "value": 2
      },
  
      {
        "source": 21,
        "target": 25,
        "value": 5
      },
  
      {
        "source": 11,
        "target": 29,
        "value": 1
      },
  
      {
        "source": 11,
        "target": 10,
        "value": 1
      },
  
      {
        "source": 10,
        "target": 12,
        "value": 1
      },
  
      {
        "source": 11,
        "target": 13,
        "value": 15
      },
  
      {
        "source": 13,
        "target": 28,
        "value": 4
      },
  
      {
        "source": 11,
        "target": 18,
        "value": 1
      },
  
      {
        "source": 11,
        "target": 24,
        "value": 1
      },
  
      {
        "source": 24,
        "target": 9,
        "value": 1
      },
  
      {
        "source": 11,
        "target": 26,
        "value": 1
      },
  
      {
        "source": 26,
        "target": 12,
        "value": 1
      },
  
      {
        "source": 14,
        "target": 29,
        "value": 4
      },
  
      {
        "source": 14,
        "target": 10,
        "value": 1
      },
  
      {
        "source": 14,
        "target": 16,
        "value": 13
      },
  
      {
        "source": 14,
        "target": 18,
        "value": 1
      },
  
      {
        "source": 14,
        "target": 21,
        "value": 3
      },
  
      {
        "source": 21,
        "target": 15,
        "value": 6
      },
  
      {
        "source": 14,
        "target": 26,
        "value": 1
      },
  
      {
        "source": 27,
        "target": 26,
        "value": 12
      },
  
      {
        "source": 18,
        "target": 12,
        "value": 1
      },
  
      {
        "source": 19,
        "target": 3,
        "value": 2
      },
  
      {
        "source": 19,
        "target": 6,
        "value": 9
      },
  
      {
        "source": 19,
        "target": 29,
        "value": 5
      },
  
      {
        "source": 19,
        "target": 10,
        "value": 3
      },
  
      {
        "source": 19,
        "target": 16,
        "value": 2
      },
  
      {
        "source": 16,
        "target": 2,
        "value": 1
      },
  
      {
        "source": 19,
        "target": 21,
        "value": 45
      },
  
      {
        "source": 21,
        "target": 12,
        "value": 1
      },
  
      {
        "source": 21,
        "target": 17,
        "value": 2
      },
  
      {
        "source": 19,
        "target": 24,
        "value": 3
      },
  
      {
        "source": 22,
        "target": 29,
        "value": 5
      },
  
      {
        "source": 22,
        "target": 6,
        "value": 1
      },
  
      {
        "source": 22,
        "target": 10,
        "value": 3
      },
  
      {
        "source": 22,
        "target": 13,
        "value": 1
      },
  
      {
        "source": 22,
        "target": 16,
        "value": 2
      },
  
      {
        "source": 22,
        "target": 21,
        "value": 3
      },
  
      {
        "source": 22,
        "target": 24,
        "value": 24
      },
  
      {
        "source": 24,
        "target": 28,
        "value": 9
      },
  
      {
        "source": 24,
        "target": 17,
        "value": 1
      },
  
      {
        "source": 24,
        "target": 20,
        "value": 1
      },
  
      {
        "source": 22,
        "target": 26,
        "value": 1
      },
  
      {
        "source": 27,
        "target": 3,
        "value": 2
      },
  
      {
        "source": 26,
        "target": 23,
        "value": 1
      }
    ]
  };
  