interface one_timeline {club_name:string,start_date:string,end_date:string}

export type ImprovedPlayer = {
    player_id: number;
    long_name: string;
    player_positions: string;
    overall: number[];
    potential: number[];
    age: number;
    player_tags: string;
    player_traits: string;
    
    value_eur: number[];
    wage_eur: number[];
    player_face_url: string;
    evolutionImageURL: string;
    skill_2023: number[];
    skill_2022: number[];
    skill_2021: number[];
    skill_2020: number[];
    skill_2019: number[];
    skill_2018: number[];
    skill_2017: number[];
    skill_2016: number[];
    timeline:  one_timeline[];
    skill_2015: number[];
}

export const ImprovedPlayers: ImprovedPlayer[] = [
    {
        "age": 23,
        "evolutionImageURL": "plots/Kylian Mbappé Lottin.html",
        "long_name": "Kylian Mbappé Lottin",
        "overall": [
            65,
            79,
            83,
            87,
            89,
            90,
            91,
            91
        ],
        "player_face_url": "https://cdn.sofifa.net/players/231/747/23_120.png",
        "player_id": 231747,
        "player_positions": "ST, LW",
        "player_tags": "#Speedster, #Dribbler, #Acrobat, #Clinical Finisher, #Complete Forward",
        "player_traits": "Solid Player, Flair, Speed Dribbler (AI), Outside Foot Shot, Technical Dribbler (AI)",
        "potential": [
            85,
            92,
            94,
            95,
            95,
            95,
            95,
            95
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            62.0,
            56.0,
            70.0,
            30.0,
            54.0,
            81.0
        ],
        "skill_2017": [
            75.0,
            72.0,
            82.0,
            47.0,
            72.0,
            88.0
        ],
        "skill_2018": [
            80.0,
            74.0,
            85.0,
            47.0,
            74.0,
            90.0
        ],
        "skill_2019": [
            81.0,
            79.0,
            89.0,
            39.0,
            72.0,
            96.0
        ],
        "skill_2020": [
            84.0,
            78.0,
            90.0,
            39.0,
            75.0,
            96.0
        ],
        "skill_2021": [
            86.0,
            78.0,
            91.0,
            39.0,
            76.0,
            96.0
        ],
        "skill_2022": [
            88.0,
            80.0,
            92.0,
            36.0,
            77.0,
            97.0
        ],
        "skill_2023": [
            89.0,
            80.0,
            92.0,
            36.0,
            76.0,
            97.0
        ],
        "timeline": [
            {
                "club_name": "Paris Saint Germain",
                "end_date": "2024-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Monaco",
                "end_date": "2018-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            1000000,
            17000000,
            41500000,
            72000000,
            93500000,
            185500000,
            194000000,
            190500000
        ],
        "wage_eur": [
            2000,
            40000,
            60000,
            80000,
            150000,
            160000,
            230000,
            230000
        ]
    },
    {
        "age": 27,
        "evolutionImageURL": "plots/Joshua Walter Kimmich.html",
        "long_name": "Joshua Walter Kimmich",
        "overall": [
            64,
            71,
            80,
            81,
            85,
            86,
            88,
            89,
            89
        ],
        "player_face_url": "https://cdn.sofifa.net/players/212/622/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM, RB, CM",
        "player_tags": "#Crosser",
        "player_traits": "Leadership, Long Passer (AI), Playmaker (AI)",
        "potential": [
            78,
            82,
            87,
            87,
            88,
            88,
            90,
            90,
            90
        ],
        "skill_2015": [
            51.0,
            65.0,
            69.0,
            54.0,
            63.0,
            69.0
        ],
        "skill_2016": [
            52.0,
            71.0,
            73.0,
            59.0,
            63.0,
            62.0
        ],
        "skill_2017": [
            67.0,
            80.0,
            78.0,
            76.0,
            71.0,
            70.0
        ],
        "skill_2018": [
            67.0,
            82.0,
            80.0,
            77.0,
            73.0,
            70.0
        ],
        "skill_2019": [
            68.0,
            83.0,
            82.0,
            77.0,
            73.0,
            73.0
        ],
        "skill_2020": [
            69.0,
            86.0,
            84.0,
            79.0,
            78.0,
            72.0
        ],
        "skill_2021": [
            72.0,
            86.0,
            84.0,
            81.0,
            79.0,
            71.0
        ],
        "skill_2022": [
            73.0,
            87.0,
            84.0,
            83.0,
            79.0,
            70.0
        ],
        "skill_2023": [
            72.0,
            87.0,
            84.0,
            83.0,
            79.0,
            68.0
        ],
        "timeline": [
            {
                "club_name": "FC Bayern München",
                "end_date": "2024-01-01",
                "start_date": "2016-01-01"
            },
            {
                "club_name": "RB Leipzig",
                "end_date": "2016-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            400000,
            2800000,
            20000000,
            20500000,
            40500000,
            48000000,
            103000000,
            108000000,
            105500000
        ],
        "wage_eur": [
            4000,
            25000,
            80000,
            80000,
            90000,
            125000,
            145000,
            160000,
            130000
        ]
    },
    {
        "age": 21,
        "evolutionImageURL": "plots/Erling Braut Haaland.html",
        "long_name": "Erling Braut Haaland",
        "overall": [
            58,
            61,
            68,
            75,
            84,
            88,
            89
        ],
        "player_face_url": "https://cdn.sofifa.net/players/239/085/23_120.png",
        "player_id": 231747,
        "player_positions": "ST",
        "player_tags": "#Aerial Threat, #Distance Shooter, #Strength, #Clinical Finisher, #Complete Forward",
        "player_traits": "Speed Dribbler (AI), Power Header",
        "potential": [
            78,
            83,
            85,
            87,
            92,
            94,
            94
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            57.0,
            44.0,
            58.0,
            18.0,
            63.0,
            69.0
        ],
        "skill_2018": [
            58.0,
            47.0,
            60.0,
            21.0,
            70.0,
            70.0
        ],
        "skill_2019": [
            64.0,
            52.0,
            66.0,
            32.0,
            78.0,
            79.0
        ],
        "skill_2020": [
            73.0,
            57.0,
            72.0,
            36.0,
            79.0,
            86.0
        ],
        "skill_2021": [
            87.0,
            63.0,
            76.0,
            43.0,
            85.0,
            85.0
        ],
        "skill_2022": [
            91.0,
            65.0,
            80.0,
            45.0,
            88.0,
            89.0
        ],
        "skill_2023": [
            91.0,
            65.0,
            80.0,
            49.0,
            88.0,
            89.0
        ],
        "timeline": [
            {
                "club_name": "Manchester City",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "Borussia Dortmund",
                "end_date": "2023-01-01",
                "start_date": "2021-01-01"
            },
            {
                "club_name": "Salzburg",
                "end_date": "2021-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Molde",
                "end_date": "2020-01-01",
                "start_date": "2017-01-01"
            }
        ],
        "value_eur": [
            250000,
            550000,
            1800000,
            11000000,
            92000000,
            143500000,
            160000000
        ],
        "wage_eur": [
            1000,
            1000,
            2000,
            15000,
            56000,
            110000,
            230000
        ]
    },
    {
        "age": 26,
        "evolutionImageURL": "plots/Mike Maignan.html",
        "long_name": "Mike Maignan",
        "overall": [
            56,
            66,
            67,
            73,
            75,
            80,
            82,
            84,
            87
        ],
        "player_face_url": "https://cdn.sofifa.net/players/215/698/23_120.png",
        "player_id": 231747,
        "player_positions": "GK",
        "player_tags": "",
        "player_traits": "Leadership, GK Long Throw, Comes For Crosses",
        "potential": [
            74,
            76,
            77,
            81,
            83,
            87,
            86,
            89,
            90
        ],
        "skill_2015": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2016": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2017": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2018": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2019": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2020": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2021": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2022": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2023": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "timeline": [
            {
                "club_name": "Milan",
                "end_date": "2024-01-01",
                "start_date": "2022-01-01"
            },
            {
                "club_name": "Lille",
                "end_date": "2022-01-01",
                "start_date": "2016-01-01"
            },
            {
                "club_name": "Paris Saint-Germain",
                "end_date": "2016-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            60000,
            775000,
            1000000,
            4400000,
            7500000,
            16000000,
            34500000,
            49500000,
            80000000
        ],
        "wage_eur": [
            2000,
            4000,
            10000,
            20000,
            15000,
            28000,
            31000,
            45000,
            90000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/Frenkie de Jong.html",
        "long_name": "Frenkie de Jong",
        "overall": [
            59,
            63,
            70,
            72,
            78,
            86,
            85,
            87,
            87
        ],
        "player_face_url": "https://cdn.sofifa.net/players/228/702/23_120.png",
        "player_id": 231747,
        "player_positions": "CM",
        "player_tags": "#Dribbler, #Playmaker, #Acrobat, #Complete Midfielder",
        "player_traits": "Finesse Shot, Flair, Playmaker (AI), Outside Foot Shot, Technical Dribbler (AI)",
        "potential": [
            76,
            79,
            80,
            82,
            86,
            92,
            90,
            92,
            92
        ],
        "skill_2015": [
            46.0,
            62.0,
            61.0,
            46.0,
            52.0,
            65.0
        ],
        "skill_2016": [
            51.0,
            65.0,
            65.0,
            48.0,
            52.0,
            66.0
        ],
        "skill_2017": [
            51.0,
            70.0,
            77.0,
            58.0,
            59.0,
            69.0
        ],
        "skill_2018": [
            51.0,
            73.0,
            79.0,
            58.0,
            60.0,
            76.0
        ],
        "skill_2019": [
            56.0,
            79.0,
            85.0,
            66.0,
            65.0,
            73.0
        ],
        "skill_2020": [
            64.0,
            84.0,
            87.0,
            76.0,
            77.0,
            78.0
        ],
        "skill_2021": [
            64.0,
            84.0,
            87.0,
            76.0,
            77.0,
            80.0
        ],
        "skill_2022": [
            69.0,
            85.0,
            88.0,
            77.0,
            78.0,
            81.0
        ],
        "skill_2023": [
            69.0,
            86.0,
            87.0,
            77.0,
            78.0,
            82.0
        ],
        "timeline": [
            {
                "club_name": "FC Barcelona",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Ajax",
                "end_date": "2020-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "Willem II",
                "end_date": "2017-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            100000,
            650000,
            1900000,
            5000000,
            15000000,
            60000000,
            81000000,
            119500000,
            116500000
        ],
        "wage_eur": [
            2000,
            2000,
            7000,
            8000,
            15000,
            210000,
            190000,
            210000,
            230000
        ]
    },
    {
        "age": 26,
        "evolutionImageURL": "plots/Rodrigo Hernández Cascante.html",
        "long_name": "Rodrigo Hernández Cascante",
        "overall": [
            67,
            70,
            72,
            82,
            85,
            85,
            86,
            87
        ],
        "player_face_url": "https://cdn.sofifa.net/players/231/866/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM",
        "player_tags": "",
        "player_traits": "Solid Player, Long Shot Taker (AI)",
        "potential": [
            80,
            80,
            80,
            87,
            90,
            88,
            89,
            89
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            50.0,
            62.0,
            55.0,
            63.0,
            63.0,
            62.0
        ],
        "skill_2017": [
            50.0,
            62.0,
            56.0,
            67.0,
            62.0,
            56.0
        ],
        "skill_2018": [
            59.0,
            65.0,
            69.0,
            69.0,
            67.0,
            62.0
        ],
        "skill_2019": [
            69.0,
            75.0,
            78.0,
            76.0,
            75.0,
            68.0
        ],
        "skill_2020": [
            68.0,
            77.0,
            77.0,
            82.0,
            80.0,
            67.0
        ],
        "skill_2021": [
            68.0,
            77.0,
            77.0,
            82.0,
            79.0,
            65.0
        ],
        "skill_2022": [
            70.0,
            77.0,
            78.0,
            82.0,
            82.0,
            61.0
        ],
        "skill_2023": [
            72.0,
            78.0,
            79.0,
            83.0,
            84.0,
            58.0
        ],
        "timeline": [
            {
                "club_name": "Manchester City",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Atlético Madrid",
                "end_date": "2020-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Villarreal",
                "end_date": "2019-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            1100000,
            1900000,
            4500000,
            29000000,
            47000000,
            66500000,
            81000000,
            88500000
        ],
        "wage_eur": [
            7000,
            15000,
            15000,
            60000,
            145000,
            145000,
            175000,
            200000
        ]
    },
    {
        "age": 23,
        "evolutionImageURL": "plots/Trent Alexander-Arnold.html",
        "long_name": "Trent Alexander-Arnold",
        "overall": [
            62,
            68,
            69,
            78,
            83,
            87,
            87,
            86
        ],
        "player_face_url": "https://cdn.sofifa.net/players/231/281/23_120.png",
        "player_id": 231747,
        "player_positions": "RB",
        "player_tags": "#Crosser",
        "player_traits": "Early Crosser, Long Passer (AI), Long Shot Taker (AI)",
        "potential": [
            78,
            82,
            85,
            88,
            89,
            92,
            90,
            89
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            46.0,
            61.0,
            59.0,
            51.0,
            59.0,
            65.0
        ],
        "skill_2017": [
            56.0,
            67.0,
            65.0,
            62.0,
            65.0,
            83.0
        ],
        "skill_2018": [
            58.0,
            70.0,
            67.0,
            64.0,
            66.0,
            81.0
        ],
        "skill_2019": [
            60.0,
            75.0,
            72.0,
            74.0,
            69.0,
            80.0
        ],
        "skill_2020": [
            62.0,
            82.0,
            78.0,
            79.0,
            70.0,
            80.0
        ],
        "skill_2021": [
            66.0,
            87.0,
            80.0,
            80.0,
            71.0,
            80.0
        ],
        "skill_2022": [
            68.0,
            88.0,
            80.0,
            80.0,
            72.0,
            78.0
        ],
        "skill_2023": [
            69.0,
            89.0,
            80.0,
            79.0,
            72.0,
            76.0
        ],
        "timeline": [
            {
                "club_name": "Liverpool",
                "end_date": "2024-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            525000,
            1500000,
            1900000,
            14000000,
            32000000,
            114000000,
            102500000,
            86000000
        ],
        "wage_eur": [
            3000,
            20000,
            20000,
            40000,
            78000,
            110000,
            150000,
            140000
        ]
    },
    {
        "age": 24,
        "evolutionImageURL": "plots/Gregor Kobel.html",
        "long_name": "Gregor Kobel",
        "overall": [
            54,
            65,
            66,
            72,
            75,
            79,
            85
        ],
        "player_face_url": "https://cdn.sofifa.net/players/235/073/23_120.png",
        "player_id": 231747,
        "player_positions": "GK",
        "player_tags": "",
        "player_traits": "Leadership, GK Long Throw, Rushes Out Of Goal, Comes For Crosses",
        "potential": [
            71,
            81,
            81,
            82,
            82,
            85,
            89
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2018": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2019": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2020": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2021": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2022": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2023": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "timeline": [
            {
                "club_name": "Borussia Dortmund",
                "end_date": "2024-01-01",
                "start_date": "2022-01-01"
            },
            {
                "club_name": "VfB Stuttgart",
                "end_date": "2022-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "TSG Hoffenheim",
                "end_date": "2020-01-01",
                "start_date": "2017-01-01"
            }
        ],
        "value_eur": [
            130000,
            950000,
            1200000,
            3900000,
            9500000,
            22500000,
            61000000
        ],
        "wage_eur": [
            2000,
            3000,
            5000,
            11000,
            14000,
            36000,
            48000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/Mikel Oyarzabal Ugarte.html",
        "long_name": "Mikel Oyarzabal Ugarte",
        "overall": [
            56,
            78,
            79,
            80,
            83,
            84,
            85,
            84
        ],
        "player_face_url": "https://cdn.sofifa.net/players/230/142/23_120.png",
        "player_id": 231747,
        "player_positions": "LW, RW",
        "player_tags": "",
        "player_traits": "Leadership, Finesse Shot, Outside Foot Shot, Technical Dribbler (AI)",
        "potential": [
            66,
            85,
            86,
            87,
            89,
            89,
            89,
            86
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            44.0,
            57.0,
            56.0,
            33.0,
            53.0,
            63.0
        ],
        "skill_2017": [
            72.0,
            74.0,
            80.0,
            33.0,
            58.0,
            73.0
        ],
        "skill_2018": [
            73.0,
            76.0,
            80.0,
            33.0,
            57.0,
            73.0
        ],
        "skill_2019": [
            75.0,
            78.0,
            82.0,
            38.0,
            58.0,
            73.0
        ],
        "skill_2020": [
            82.0,
            79.0,
            83.0,
            39.0,
            63.0,
            80.0
        ],
        "skill_2021": [
            82.0,
            80.0,
            84.0,
            41.0,
            63.0,
            82.0
        ],
        "skill_2022": [
            82.0,
            81.0,
            84.0,
            41.0,
            63.0,
            82.0
        ],
        "skill_2023": [
            83.0,
            80.0,
            83.0,
            41.0,
            62.0,
            79.0
        ],
        "timeline": [
            {
                "club_name": "Real Sociedad",
                "end_date": "2024-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            140000,
            10500000,
            18000000,
            21000000,
            35500000,
            63500000,
            77500000,
            53000000
        ],
        "wage_eur": [
            2000,
            20000,
            30000,
            30000,
            43000,
            47000,
            57000,
            57000
        ]
    },
    {
        "age": 23,
        "evolutionImageURL": "plots/Declan Rice.html",
        "long_name": "Declan Rice",
        "overall": [
            57,
            60,
            70,
            78,
            79,
            82,
            84
        ],
        "player_face_url": "https://cdn.sofifa.net/players/234/378/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM, CM",
        "player_tags": "",
        "player_traits": "Leadership, Long Passer (AI)",
        "potential": [
            71,
            78,
            83,
            87,
            86,
            87,
            87
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            29.0,
            36.0,
            41.0,
            57.0,
            63.0,
            62.0
        ],
        "skill_2018": [
            30.0,
            47.0,
            51.0,
            61.0,
            67.0,
            63.0
        ],
        "skill_2019": [
            32.0,
            57.0,
            59.0,
            71.0,
            71.0,
            61.0
        ],
        "skill_2020": [
            37.0,
            64.0,
            68.0,
            77.0,
            77.0,
            62.0
        ],
        "skill_2021": [
            44.0,
            65.0,
            69.0,
            78.0,
            77.0,
            65.0
        ],
        "skill_2022": [
            60.0,
            71.0,
            74.0,
            81.0,
            80.0,
            68.0
        ],
        "skill_2023": [
            65.0,
            75.0,
            76.0,
            82.0,
            83.0,
            71.0
        ],
        "timeline": [
            {
                "club_name": "West Ham United",
                "end_date": "2024-01-01",
                "start_date": "2017-01-01"
            }
        ],
        "value_eur": [
            200000,
            375000,
            3000000,
            15000000,
            33500000,
            43000000,
            52000000
        ],
        "wage_eur": [
            6000,
            6000,
            15000,
            49000,
            31000,
            69000,
            83000
        ]
    },
    {
        "age": 23,
        "evolutionImageURL": "plots/Kai Lukas Havertz.html",
        "long_name": "Kai Lukas Havertz",
        "overall": [
            70,
            73,
            79,
            84,
            85,
            84,
            84
        ],
        "player_face_url": "https://cdn.sofifa.net/players/235/790/23_120.png",
        "player_id": 231747,
        "player_positions": "CAM, CF, ST",
        "player_tags": "",
        "player_traits": "Finesse Shot, Playmaker (AI), Outside Foot Shot, Chip Shot (AI), Technical Dribbler (AI)",
        "potential": [
            87,
            88,
            88,
            92,
            93,
            92,
            91
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            57.0,
            68.0,
            72.0,
            40.0,
            55.0,
            72.0
        ],
        "skill_2018": [
            59.0,
            71.0,
            75.0,
            40.0,
            57.0,
            72.0
        ],
        "skill_2019": [
            64.0,
            76.0,
            80.0,
            38.0,
            60.0,
            77.0
        ],
        "skill_2020": [
            78.0,
            79.0,
            84.0,
            44.0,
            65.0,
            84.0
        ],
        "skill_2021": [
            81.0,
            79.0,
            85.0,
            45.0,
            67.0,
            84.0
        ],
        "skill_2022": [
            78.0,
            79.0,
            84.0,
            45.0,
            66.0,
            82.0
        ],
        "skill_2023": [
            79.0,
            79.0,
            84.0,
            45.0,
            68.0,
            81.0
        ],
        "timeline": [
            {
                "club_name": "Chelsea",
                "end_date": "2024-01-01",
                "start_date": "2021-01-01"
            },
            {
                "club_name": "Bayer 04 Leverkusen",
                "end_date": "2021-01-01",
                "start_date": "2017-01-01"
            }
        ],
        "value_eur": [
            2500000,
            8000000,
            19000000,
            46000000,
            121000000,
            94500000,
            84500000
        ],
        "wage_eur": [
            20000,
            20000,
            30000,
            70000,
            105000,
            130000,
            130000
        ]
    },
    {
        "age": 22,
        "evolutionImageURL": "plots/Sandro Tonali.html",
        "long_name": "Sandro Tonali",
        "overall": [
            65,
            67,
            76,
            77,
            78,
            84
        ],
        "player_face_url": "https://cdn.sofifa.net/players/241/096/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM, CM",
        "player_tags": "",
        "player_traits": "Long Passer (AI), Team Player",
        "potential": [
            87,
            88,
            90,
            91,
            87,
            90
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2018": [
            51.0,
            68.0,
            66.0,
            60.0,
            63.0,
            68.0
        ],
        "skill_2019": [
            52.0,
            69.0,
            68.0,
            61.0,
            68.0,
            68.0
        ],
        "skill_2020": [
            66.0,
            76.0,
            76.0,
            72.0,
            76.0,
            79.0
        ],
        "skill_2021": [
            65.0,
            78.0,
            77.0,
            72.0,
            76.0,
            80.0
        ],
        "skill_2022": [
            67.0,
            78.0,
            77.0,
            74.0,
            77.0,
            79.0
        ],
        "skill_2023": [
            73.0,
            81.0,
            79.0,
            79.0,
            82.0,
            81.0
        ],
        "timeline": [
            {
                "club_name": "Milan",
                "end_date": "2024-01-01",
                "start_date": "2021-01-01"
            },
            {
                "club_name": "Brescia",
                "end_date": "2021-01-01",
                "start_date": "2018-01-01"
            }
        ],
        "value_eur": [
            1100000,
            1600000,
            15500000,
            24000000,
            30000000,
            62500000
        ],
        "wage_eur": [
            1000,
            1000,
            8000,
            25000,
            26000,
            75000
        ]
    },
    {
        "age": 22,
        "evolutionImageURL": "plots/Moussa Diaby.html",
        "long_name": "Moussa Diaby",
        "overall": [
            56,
            68,
            74,
            81,
            81,
            84
        ],
        "player_face_url": "https://cdn.sofifa.net/players/241/852/23_120.png",
        "player_id": 231747,
        "player_positions": "RM, LM, LW",
        "player_tags": "#Speedster, #Dribbler, #Acrobat",
        "player_traits": "Speed Dribbler (AI), Technical Dribbler (AI)",
        "potential": [
            73,
            83,
            85,
            88,
            88,
            88
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2018": [
            53.0,
            49.0,
            64.0,
            36.0,
            37.0,
            73.0
        ],
        "skill_2019": [
            61.0,
            62.0,
            74.0,
            36.0,
            42.0,
            78.0
        ],
        "skill_2020": [
            62.0,
            68.0,
            78.0,
            42.0,
            51.0,
            87.0
        ],
        "skill_2021": [
            66.0,
            74.0,
            85.0,
            43.0,
            53.0,
            94.0
        ],
        "skill_2022": [
            68.0,
            73.0,
            85.0,
            41.0,
            53.0,
            94.0
        ],
        "skill_2023": [
            73.0,
            75.0,
            87.0,
            42.0,
            59.0,
            93.0
        ],
        "timeline": [
            {
                "club_name": "Bayer 04 Leverkusen",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Paris Saint Germain",
                "end_date": "2020-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Crotone",
                "end_date": "2019-01-01",
                "start_date": "2018-01-01"
            }
        ],
        "value_eur": [
            180000,
            1800000,
            9500000,
            51000000,
            52500000,
            61500000
        ],
        "wage_eur": [
            2000,
            15000,
            26000,
            54000,
            52000,
            70000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/Konrad Laimer.html",
        "long_name": "Konrad Laimer",
        "overall": [
            51,
            59,
            68,
            70,
            75,
            77,
            82,
            81,
            83
        ],
        "player_face_url": "https://cdn.sofifa.net/players/225/375/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM, CM",
        "player_tags": "#Tactician ",
        "player_traits": "Dives Into Tackles (AI)",
        "potential": [
            57,
            75,
            79,
            80,
            82,
            83,
            86,
            85,
            84
        ],
        "skill_2015": [
            44.0,
            47.0,
            55.0,
            28.0,
            47.0,
            68.0
        ],
        "skill_2016": [
            54.0,
            59.0,
            64.0,
            43.0,
            55.0,
            77.0
        ],
        "skill_2017": [
            59.0,
            63.0,
            67.0,
            62.0,
            68.0,
            77.0
        ],
        "skill_2018": [
            61.0,
            65.0,
            68.0,
            65.0,
            70.0,
            76.0
        ],
        "skill_2019": [
            63.0,
            70.0,
            74.0,
            71.0,
            73.0,
            75.0
        ],
        "skill_2020": [
            65.0,
            73.0,
            78.0,
            73.0,
            73.0,
            83.0
        ],
        "skill_2021": [
            68.0,
            78.0,
            78.0,
            80.0,
            77.0,
            85.0
        ],
        "skill_2022": [
            68.0,
            77.0,
            78.0,
            80.0,
            77.0,
            81.0
        ],
        "skill_2023": [
            68.0,
            78.0,
            79.0,
            81.0,
            78.0,
            80.0
        ],
        "timeline": [
            {
                "club_name": "RB Leipzig",
                "end_date": "2024-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Salzburg",
                "end_date": "2018-01-01",
                "start_date": "2016-01-01"
            },
            {
                "club_name": "FC Red Bull Salzburg",
                "end_date": "2016-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            40000,
            300000,
            1300000,
            2800000,
            8000000,
            12000000,
            40000000,
            33500000,
            38500000
        ],
        "wage_eur": [
            2000,
            2000,
            10000,
            30000,
            30000,
            41000,
            53000,
            65000,
            64000
        ]
    },
    {
        "age": 27,
        "evolutionImageURL": "plots/Ferland Mendy.html",
        "long_name": "Ferland Mendy",
        "overall": [
            51,
            54,
            66,
            72,
            78,
            80,
            83,
            83,
            83
        ],
        "player_face_url": "https://cdn.sofifa.net/players/228/618/23_120.png",
        "player_id": 231747,
        "player_positions": "LB",
        "player_tags": "#Speedster, #Engine",
        "player_traits": "Flair, Speed Dribbler (AI)",
        "potential": [
            62,
            65,
            77,
            81,
            86,
            86,
            88,
            86,
            84
        ],
        "skill_2015": [
            26.0,
            33.0,
            48.0,
            54.0,
            65.0,
            73.0
        ],
        "skill_2016": [
            27.0,
            34.0,
            49.0,
            57.0,
            65.0,
            73.0
        ],
        "skill_2017": [
            38.0,
            53.0,
            61.0,
            63.0,
            73.0,
            72.0
        ],
        "skill_2018": [
            52.0,
            64.0,
            71.0,
            68.0,
            76.0,
            81.0
        ],
        "skill_2019": [
            63.0,
            73.0,
            79.0,
            73.0,
            78.0,
            87.0
        ],
        "skill_2020": [
            64.0,
            73.0,
            79.0,
            75.0,
            81.0,
            89.0
        ],
        "skill_2021": [
            64.0,
            76.0,
            79.0,
            78.0,
            82.0,
            92.0
        ],
        "skill_2022": [
            64.0,
            76.0,
            79.0,
            78.0,
            84.0,
            92.0
        ],
        "skill_2023": [
            64.0,
            77.0,
            78.0,
            78.0,
            84.0,
            92.0
        ],
        "timeline": [
            {
                "club_name": "Real Madrid",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Olympique Lyonnais",
                "end_date": "2020-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Le Havre",
                "end_date": "2018-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            35000,
            110000,
            925000,
            4100000,
            13000000,
            18000000,
            49500000,
            43500000,
            38000000
        ],
        "wage_eur": [
            2000,
            2000,
            2000,
            30000,
            50000,
            115000,
            160000,
            170000,
            170000
        ]
    },
    {
        "age": 23,
        "evolutionImageURL": "plots/Dayotchanculle Oswald Upamecano.html",
        "long_name": "Dayotchanculle Oswald Upamecano",
        "overall": [
            53,
            66,
            71,
            76,
            77,
            80,
            82,
            83
        ],
        "player_face_url": "https://cdn.sofifa.net/players/229/558/23_120.png",
        "player_id": 231747,
        "player_positions": "CB",
        "player_tags": "#Tackling, #Strength",
        "player_traits": "",
        "potential": [
            75,
            86,
            86,
            88,
            88,
            90,
            90,
            87
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            24.0,
            31.0,
            30.0,
            55.0,
            54.0,
            49.0
        ],
        "skill_2017": [
            32.0,
            52.0,
            55.0,
            64.0,
            70.0,
            71.0
        ],
        "skill_2018": [
            32.0,
            53.0,
            57.0,
            69.0,
            71.0,
            79.0
        ],
        "skill_2019": [
            36.0,
            59.0,
            61.0,
            74.0,
            80.0,
            79.0
        ],
        "skill_2020": [
            36.0,
            59.0,
            61.0,
            75.0,
            80.0,
            76.0
        ],
        "skill_2021": [
            40.0,
            62.0,
            68.0,
            80.0,
            82.0,
            78.0
        ],
        "skill_2022": [
            43.0,
            62.0,
            68.0,
            81.0,
            81.0,
            81.0
        ],
        "skill_2023": [
            43.0,
            62.0,
            70.0,
            82.0,
            82.0,
            82.0
        ],
        "timeline": [
            {
                "club_name": "FC Bayern München",
                "end_date": "2024-01-01",
                "start_date": "2022-01-01"
            },
            {
                "club_name": "RB Leipzig",
                "end_date": "2022-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "FC Red Bull Salzburg",
                "end_date": "2017-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            110000,
            1100000,
            4400000,
            12000000,
            14000000,
            44500000,
            64000000,
            47000000
        ],
        "wage_eur": [
            2000,
            6000,
            15000,
            15000,
            31000,
            38000,
            70000,
            64000
        ]
    },
    {
        "age": 24,
        "evolutionImageURL": "plots/Cristian Gabriel Romero.html",
        "long_name": "Cristian Gabriel Romero",
        "overall": [
            56,
            63,
            63,
            72,
            74,
            73,
            82,
            83
        ],
        "player_face_url": "https://cdn.sofifa.net/players/232/488/23_120.png",
        "player_id": 231747,
        "player_positions": "CB",
        "player_tags": "#Tackling ",
        "player_traits": "Dives Into Tackles (AI), Long Passer (AI)",
        "potential": [
            66,
            77,
            77,
            86,
            88,
            79,
            87,
            88
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            34.0,
            35.0,
            36.0,
            58.0,
            63.0,
            61.0
        ],
        "skill_2017": [
            34.0,
            39.0,
            40.0,
            63.0,
            71.0,
            62.0
        ],
        "skill_2018": [
            34.0,
            39.0,
            40.0,
            63.0,
            71.0,
            61.0
        ],
        "skill_2019": [
            35.0,
            42.0,
            47.0,
            70.0,
            78.0,
            63.0
        ],
        "skill_2020": [
            35.0,
            43.0,
            48.0,
            74.0,
            77.0,
            64.0
        ],
        "skill_2021": [
            35.0,
            43.0,
            48.0,
            74.0,
            76.0,
            62.0
        ],
        "skill_2022": [
            46.0,
            52.0,
            61.0,
            83.0,
            84.0,
            74.0
        ],
        "skill_2023": [
            46.0,
            59.0,
            66.0,
            85.0,
            81.0,
            73.0
        ],
        "timeline": [
            {
                "club_name": "Tottenham Hotspur",
                "end_date": "2024-01-01",
                "start_date": "2022-01-01"
            },
            {
                "club_name": "Atalanta",
                "end_date": "2022-01-01",
                "start_date": "2021-01-01"
            },
            {
                "club_name": "Genoa",
                "end_date": "2021-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Belgrano",
                "end_date": "2019-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            120000,
            575000,
            725000,
            6000000,
            11500000,
            4400000,
            41500000,
            49500000
        ],
        "wage_eur": [
            2000,
            2000,
            2000,
            9000,
            10000,
            29000,
            51000,
            95000
        ]
    },
    {
        "age": 22,
        "evolutionImageURL": "plots/Jadon Sancho.html",
        "long_name": "Jadon Sancho",
        "overall": [
            63,
            73,
            84,
            87,
            87,
            83
        ],
        "player_face_url": "https://cdn.sofifa.net/players/233/049/23_120.png",
        "player_id": 231747,
        "player_positions": "LW, RW, LM",
        "player_tags": "#Dribbler",
        "player_traits": "Finesse Shot, Flair, Playmaker (AI)",
        "potential": [
            86,
            88,
            92,
            93,
            91,
            87
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2018": [
            55.0,
            55.0,
            71.0,
            30.0,
            47.0,
            76.0
        ],
        "skill_2019": [
            58.0,
            63.0,
            84.0,
            32.0,
            52.0,
            85.0
        ],
        "skill_2020": [
            72.0,
            77.0,
            90.0,
            36.0,
            60.0,
            88.0
        ],
        "skill_2021": [
            74.0,
            81.0,
            91.0,
            37.0,
            64.0,
            83.0
        ],
        "skill_2022": [
            76.0,
            82.0,
            91.0,
            36.0,
            65.0,
            81.0
        ],
        "skill_2023": [
            70.0,
            80.0,
            87.0,
            33.0,
            49.0,
            79.0
        ],
        "timeline": [
            {
                "club_name": "Manchester United",
                "end_date": "2024-01-01",
                "start_date": "2022-01-01"
            },
            {
                "club_name": "Borussia Dortmund",
                "end_date": "2022-01-01",
                "start_date": "2018-01-01"
            }
        ],
        "value_eur": [
            800000,
            8000000,
            44500000,
            124000000,
            116500000,
            53000000
        ],
        "wage_eur": [
            6000,
            15000,
            61000,
            82000,
            150000,
            140000
        ]
    },
    {
        "age": 23,
        "evolutionImageURL": "plots/Mason Mount.html",
        "long_name": "Mason Mount",
        "overall": [
            58,
            65,
            75,
            75,
            80,
            83,
            83
        ],
        "player_face_url": "https://cdn.sofifa.net/players/233/064/23_120.png",
        "player_id": 231747,
        "player_positions": "CAM, RW, CM",
        "player_tags": "#Engine",
        "player_traits": "Long Shot Taker (AI), Technical Dribbler (AI)",
        "potential": [
            80,
            83,
            86,
            86,
            87,
            89,
            86
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            56.0,
            56.0,
            57.0,
            31.0,
            39.0,
            69.0
        ],
        "skill_2018": [
            58.0,
            64.0,
            71.0,
            44.0,
            47.0,
            69.0
        ],
        "skill_2019": [
            67.0,
            74.0,
            77.0,
            44.0,
            51.0,
            73.0
        ],
        "skill_2020": [
            68.0,
            75.0,
            77.0,
            46.0,
            53.0,
            71.0
        ],
        "skill_2021": [
            77.0,
            79.0,
            80.0,
            48.0,
            61.0,
            74.0
        ],
        "skill_2022": [
            79.0,
            84.0,
            83.0,
            55.0,
            65.0,
            74.0
        ],
        "skill_2023": [
            81.0,
            84.0,
            82.0,
            55.0,
            67.0,
            74.0
        ],
        "timeline": [
            {
                "club_name": "Chelsea",
                "end_date": "2024-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "Derby County",
                "end_date": "2020-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Vitesse",
                "end_date": "2019-01-01",
                "start_date": "2018-01-01"
            }
        ],
        "value_eur": [
            275000,
            1100000,
            11000000,
            11500000,
            43000000,
            58500000,
            49500000
        ],
        "wage_eur": [
            8000,
            3000,
            20000,
            57000,
            70000,
            120000,
            120000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/José Ángel Esmoris Tasende.html",
        "long_name": "José Ángel Esmoris Tasende",
        "overall": [
            54,
            63,
            68,
            68,
            74,
            79,
            80,
            83,
            82
        ],
        "player_face_url": "https://cdn.sofifa.net/players/220/651/23_120.png",
        "player_id": 231747,
        "player_positions": "LWB, LM",
        "player_tags": "#Crosser",
        "player_traits": "Early Crosser, Flair, Long Shot Taker (AI), Outside Foot Shot, Technical Dribbler (AI)",
        "potential": [
            80,
            81,
            78,
            78,
            81,
            84,
            85,
            86,
            84
        ],
        "skill_2015": [
            50.0,
            57.0,
            58.0,
            52.0,
            47.0,
            75.0
        ],
        "skill_2016": [
            53.0,
            61.0,
            66.0,
            60.0,
            44.0,
            78.0
        ],
        "skill_2017": [
            53.0,
            66.0,
            68.0,
            62.0,
            55.0,
            79.0
        ],
        "skill_2018": [
            53.0,
            66.0,
            68.0,
            62.0,
            55.0,
            79.0
        ],
        "skill_2019": [
            63.0,
            75.0,
            76.0,
            65.0,
            74.0,
            85.0
        ],
        "skill_2020": [
            64.0,
            79.0,
            81.0,
            72.0,
            78.0,
            85.0
        ],
        "skill_2021": [
            68.0,
            80.0,
            81.0,
            75.0,
            72.0,
            73.0
        ],
        "skill_2022": [
            71.0,
            82.0,
            84.0,
            76.0,
            70.0,
            78.0
        ],
        "skill_2023": [
            71.0,
            82.0,
            84.0,
            75.0,
            70.0,
            78.0
        ],
        "timeline": [
            {
                "club_name": "TSG Hoffenheim",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "RB Leipzig",
                "end_date": "2023-01-01",
                "start_date": "2021-01-01"
            },
            {
                "club_name": "Manchester City",
                "end_date": "2021-01-01",
                "start_date": "2015-01-01"
            },
            {
                "club_name": "PSV",
                "end_date": "2020-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "NAC Breda",
                "end_date": "2019-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Mallorca",
                "end_date": "2018-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "New York City",
                "end_date": "2017-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            60000,
            575000,
            1100000,
            1300000,
            6500000,
            15000000,
            29500000,
            46000000,
            35000000
        ],
        "wage_eur": [
            2000,
            2000,
            4000,
            5000,
            10000,
            90000,
            95000,
            77000,
            59000
        ]
    },
    {
        "age": 29,
        "evolutionImageURL": "plots/Borja Iglesias Quintás.html",
        "long_name": "Borja Iglesias Quintás",
        "overall": [
            50,
            65,
            66,
            70,
            76,
            83,
            79,
            80,
            82
        ],
        "player_face_url": "https://cdn.sofifa.net/players/224/179/23_120.png",
        "player_id": 231747,
        "player_positions": "ST",
        "player_tags": "#Strength",
        "player_traits": "Finesse Shot, Outside Foot Shot",
        "potential": [
            55,
            71,
            72,
            77,
            81,
            86,
            80,
            80,
            82
        ],
        "skill_2015": [
            53.0,
            38.0,
            46.0,
            26.0,
            57.0,
            52.0
        ],
        "skill_2016": [
            66.0,
            48.0,
            61.0,
            22.0,
            63.0,
            58.0
        ],
        "skill_2017": [
            66.0,
            47.0,
            59.0,
            22.0,
            63.0,
            56.0
        ],
        "skill_2018": [
            72.0,
            56.0,
            64.0,
            24.0,
            73.0,
            63.0
        ],
        "skill_2019": [
            79.0,
            61.0,
            71.0,
            29.0,
            76.0,
            62.0
        ],
        "skill_2020": [
            83.0,
            63.0,
            76.0,
            35.0,
            82.0,
            67.0
        ],
        "skill_2021": [
            78.0,
            64.0,
            73.0,
            35.0,
            80.0,
            66.0
        ],
        "skill_2022": [
            80.0,
            64.0,
            74.0,
            35.0,
            80.0,
            65.0
        ],
        "skill_2023": [
            83.0,
            66.0,
            74.0,
            40.0,
            81.0,
            68.0
        ],
        "timeline": [
            {
                "club_name": "Real Betis",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Espanyol",
                "end_date": "2020-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Real Zaragoza",
                "end_date": "2019-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Celta de Vigo",
                "end_date": "2018-01-01",
                "start_date": "2016-01-01"
            },
            {
                "club_name": "RC Celta de Vigo",
                "end_date": "2016-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            30000,
            750000,
            875000,
            2500000,
            10500000,
            32500000,
            20500000,
            21500000,
            30500000
        ],
        "wage_eur": [
            2000,
            5000,
            7000,
            9000,
            30000,
            41000,
            31000,
            34000,
            39000
        ]
    },
    {
        "age": 24,
        "evolutionImageURL": "plots/Ismaël Bennacer.html",
        "long_name": "Ismaël Bennacer",
        "overall": [
            54,
            56,
            62,
            62,
            71,
            74,
            75,
            80,
            82
        ],
        "player_face_url": "https://cdn.sofifa.net/players/226/754/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM, CM",
        "player_tags": "#Dribbler, #Acrobat",
        "player_traits": "Technical Dribbler (AI)",
        "potential": [
            74,
            76,
            74,
            74,
            82,
            84,
            82,
            84,
            86
        ],
        "skill_2015": [
            46.0,
            49.0,
            60.0,
            31.0,
            45.0,
            73.0
        ],
        "skill_2016": [
            47.0,
            50.0,
            61.0,
            32.0,
            45.0,
            73.0
        ],
        "skill_2017": [
            47.0,
            63.0,
            68.0,
            47.0,
            48.0,
            73.0
        ],
        "skill_2018": [
            47.0,
            63.0,
            68.0,
            47.0,
            49.0,
            69.0
        ],
        "skill_2019": [
            67.0,
            69.0,
            73.0,
            62.0,
            54.0,
            70.0
        ],
        "skill_2020": [
            70.0,
            73.0,
            74.0,
            68.0,
            66.0,
            72.0
        ],
        "skill_2021": [
            65.0,
            74.0,
            79.0,
            70.0,
            67.0,
            71.0
        ],
        "skill_2022": [
            67.0,
            80.0,
            84.0,
            73.0,
            73.0,
            73.0
        ],
        "skill_2023": [
            68.0,
            80.0,
            86.0,
            77.0,
            76.0,
            77.0
        ],
        "timeline": [
            {
                "club_name": "Milan",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Empoli",
                "end_date": "2020-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Tours",
                "end_date": "2018-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "Arsenal",
                "end_date": "2017-01-01",
                "start_date": "2016-01-01"
            },
            {
                "club_name": "Arles",
                "end_date": "2016-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            80000,
            200000,
            425000,
            525000,
            4000000,
            9000000,
            10500000,
            30000000,
            40000000
        ],
        "wage_eur": [
            2000,
            2000,
            1000,
            500,
            8000,
            23000,
            26000,
            41000,
            63000
        ]
    },
    {
        "age": 23,
        "evolutionImageURL": "plots/Christian Pulisic.html",
        "long_name": "Christian Pulisic",
        "overall": [
            65,
            76,
            78,
            79,
            79,
            81,
            82,
            82
        ],
        "player_face_url": "https://cdn.sofifa.net/players/227/796/23_120.png",
        "player_id": 231747,
        "player_positions": "LW, RW, LM",
        "player_tags": "#Dribbler",
        "player_traits": "Injury Prone, Speed Dribbler (AI)",
        "potential": [
            83,
            89,
            89,
            88,
            86,
            87,
            88,
            88
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            53.0,
            57.0,
            73.0,
            29.0,
            43.0,
            80.0
        ],
        "skill_2017": [
            67.0,
            67.0,
            81.0,
            31.0,
            55.0,
            89.0
        ],
        "skill_2018": [
            68.0,
            70.0,
            84.0,
            33.0,
            56.0,
            91.0
        ],
        "skill_2019": [
            69.0,
            71.0,
            85.0,
            36.0,
            58.0,
            91.0
        ],
        "skill_2020": [
            68.0,
            70.0,
            84.0,
            36.0,
            58.0,
            90.0
        ],
        "skill_2021": [
            70.0,
            72.0,
            85.0,
            37.0,
            59.0,
            89.0
        ],
        "skill_2022": [
            70.0,
            73.0,
            86.0,
            37.0,
            59.0,
            89.0
        ],
        "skill_2023": [
            71.0,
            73.0,
            86.0,
            37.0,
            58.0,
            87.0
        ],
        "timeline": [
            {
                "club_name": "Chelsea",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Borussia Dortmund",
                "end_date": "2020-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            1000000,
            8500000,
            16500000,
            19000000,
            18000000,
            41500000,
            49000000,
            48000000
        ],
        "wage_eur": [
            4000,
            30000,
            30000,
            30000,
            85000,
            83000,
            120000,
            120000
        ]
    },
    {
        "age": 28,
        "evolutionImageURL": "plots/Aritz Elustondo Irribaria.html",
        "long_name": "Aritz Elustondo Irribaria",
        "overall": [
            65,
            65,
            75,
            76,
            75,
            77,
            78,
            79,
            81
        ],
        "player_face_url": "https://cdn.sofifa.net/players/226/221/23_120.png",
        "player_id": 231747,
        "player_positions": "CB, RB",
        "player_tags": "",
        "player_traits": "Solid Player, Long Passer (AI)",
        "potential": [
            72,
            72,
            83,
            83,
            79,
            81,
            82,
            81,
            82
        ],
        "skill_2015": [
            31.0,
            48.0,
            46.0,
            66.0,
            63.0,
            61.0
        ],
        "skill_2016": [
            32.0,
            50.0,
            48.0,
            68.0,
            62.0,
            65.0
        ],
        "skill_2017": [
            33.0,
            53.0,
            58.0,
            76.0,
            72.0,
            71.0
        ],
        "skill_2018": [
            33.0,
            56.0,
            59.0,
            78.0,
            72.0,
            71.0
        ],
        "skill_2019": [
            33.0,
            57.0,
            60.0,
            73.0,
            72.0,
            69.0
        ],
        "skill_2020": [
            33.0,
            58.0,
            59.0,
            75.0,
            74.0,
            66.0
        ],
        "skill_2021": [
            33.0,
            58.0,
            59.0,
            79.0,
            77.0,
            67.0
        ],
        "skill_2022": [
            33.0,
            61.0,
            60.0,
            79.0,
            77.0,
            66.0
        ],
        "skill_2023": [
            39.0,
            64.0,
            61.0,
            81.0,
            78.0,
            64.0
        ],
        "timeline": [
            {
                "club_name": "Real Sociedad",
                "end_date": "2024-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            375000,
            625000,
            5000000,
            9500000,
            7500000,
            10500000,
            17500000,
            18500000,
            24500000
        ],
        "wage_eur": [
            6000,
            5000,
            20000,
            20000,
            20000,
            25000,
            28000,
            34000,
            40000
        ]
    },
    {
        "age": 26,
        "evolutionImageURL": "plots/Giovani Lo Celso.html",
        "long_name": "Giovani Lo Celso",
        "overall": [
            53,
            53,
            74,
            74,
            80,
            83,
            82,
            81,
            81
        ],
        "player_face_url": "https://cdn.sofifa.net/players/226/226/23_120.png",
        "player_id": 231747,
        "player_positions": "CAM, LM, ST",
        "player_tags": "",
        "player_traits": "Finesse Shot, Flair, Playmaker (AI), Outside Foot Shot, Technical Dribbler (AI)",
        "potential": [
            70,
            64,
            86,
            86,
            86,
            89,
            87,
            85,
            84
        ],
        "skill_2015": [
            44.0,
            50.0,
            56.0,
            24.0,
            43.0,
            65.0
        ],
        "skill_2016": [
            45.0,
            51.0,
            57.0,
            22.0,
            44.0,
            65.0
        ],
        "skill_2017": [
            58.0,
            76.0,
            76.0,
            40.0,
            63.0,
            77.0
        ],
        "skill_2018": [
            62.0,
            76.0,
            77.0,
            40.0,
            63.0,
            75.0
        ],
        "skill_2019": [
            74.0,
            79.0,
            81.0,
            64.0,
            70.0,
            74.0
        ],
        "skill_2020": [
            78.0,
            82.0,
            85.0,
            65.0,
            72.0,
            77.0
        ],
        "skill_2021": [
            77.0,
            82.0,
            85.0,
            65.0,
            74.0,
            77.0
        ],
        "skill_2022": [
            76.0,
            82.0,
            83.0,
            69.0,
            73.0,
            75.0
        ],
        "skill_2023": [
            75.0,
            83.0,
            84.0,
            68.0,
            72.0,
            71.0
        ],
        "timeline": [
            {
                "club_name": "Villarreal",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "Tottenham Hotspur",
                "end_date": "2023-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Real Betis",
                "end_date": "2020-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Paris Saint Germain",
                "end_date": "2019-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "Rosario Central",
                "end_date": "2017-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            40000,
            90000,
            6000000,
            10000000,
            20000000,
            35000000,
            46000000,
            35500000,
            33500000
        ],
        "wage_eur": [
            2000,
            2000,
            50000,
            50000,
            30000,
            33000,
            95000,
            95000,
            100000
        ]
    },
    {
        "age": 26,
        "evolutionImageURL": "plots/Manuel Obafemi Akanji.html",
        "long_name": "Manuel Obafemi Akanji",
        "overall": [
            52,
            67,
            72,
            79,
            82,
            78,
            81,
            81
        ],
        "player_face_url": "https://cdn.sofifa.net/players/229/237/23_120.png",
        "player_id": 231747,
        "player_positions": "CB",
        "player_tags": "",
        "player_traits": "",
        "potential": [
            64,
            80,
            83,
            87,
            88,
            84,
            84,
            82
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            27.0,
            28.0,
            33.0,
            53.0,
            63.0,
            54.0
        ],
        "skill_2017": [
            36.0,
            43.0,
            53.0,
            68.0,
            66.0,
            72.0
        ],
        "skill_2018": [
            36.0,
            48.0,
            61.0,
            73.0,
            70.0,
            56.0
        ],
        "skill_2019": [
            42.0,
            65.0,
            70.0,
            79.0,
            79.0,
            80.0
        ],
        "skill_2020": [
            45.0,
            68.0,
            71.0,
            82.0,
            79.0,
            78.0
        ],
        "skill_2021": [
            47.0,
            68.0,
            71.0,
            80.0,
            76.0,
            77.0
        ],
        "skill_2022": [
            48.0,
            67.0,
            74.0,
            82.0,
            77.0,
            81.0
        ],
        "skill_2023": [
            48.0,
            70.0,
            74.0,
            83.0,
            78.0,
            77.0
        ],
        "timeline": [
            {
                "club_name": "Manchester City",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "Borussia Dortmund",
                "end_date": "2023-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Basel",
                "end_date": "2019-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            70000,
            1300000,
            4700000,
            16000000,
            27500000,
            20000000,
            30500000,
            26500000
        ],
        "wage_eur": [
            2000,
            10000,
            15000,
            40000,
            70000,
            42000,
            58000,
            120000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/Denis Lemi Zakaria Lako Lado.html",
        "long_name": "Denis Lemi Zakaria Lako Lado",
        "overall": [
            60,
            72,
            72,
            77,
            79,
            83,
            80,
            81
        ],
        "player_face_url": "https://cdn.sofifa.net/players/229/261/23_120.png",
        "player_id": 231747,
        "player_positions": "CDM, CM",
        "player_tags": "",
        "player_traits": "",
        "potential": [
            77,
            86,
            86,
            86,
            86,
            87,
            86,
            86
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            34.0,
            56.0,
            60.0,
            57.0,
            75.0,
            70.0
        ],
        "skill_2017": [
            40.0,
            72.0,
            72.0,
            69.0,
            79.0,
            70.0
        ],
        "skill_2018": [
            40.0,
            72.0,
            72.0,
            69.0,
            79.0,
            70.0
        ],
        "skill_2019": [
            56.0,
            74.0,
            74.0,
            78.0,
            82.0,
            78.0
        ],
        "skill_2020": [
            63.0,
            75.0,
            77.0,
            79.0,
            82.0,
            82.0
        ],
        "skill_2021": [
            64.0,
            75.0,
            77.0,
            81.0,
            85.0,
            83.0
        ],
        "skill_2022": [
            64.0,
            72.0,
            75.0,
            80.0,
            84.0,
            83.0
        ],
        "skill_2023": [
            64.0,
            73.0,
            77.0,
            80.0,
            84.0,
            82.0
        ],
        "timeline": [
            {
                "club_name": "Chelsea",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "Borussia Mönchengladbach",
                "end_date": "2023-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Young Boys",
                "end_date": "2018-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            350000,
            4300000,
            7000000,
            13500000,
            17500000,
            47500000,
            30500000,
            34500000
        ],
        "wage_eur": [
            2000,
            10000,
            20000,
            20000,
            29000,
            45000,
            28000,
            95000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/Florian Christian Neuhaus.html",
        "long_name": "Florian Christian Neuhaus",
        "overall": [
            56,
            66,
            73,
            78,
            79,
            82,
            80
        ],
        "player_face_url": "https://cdn.sofifa.net/players/234/943/23_120.png",
        "player_id": 231747,
        "player_positions": "CM",
        "player_tags": "",
        "player_traits": "Long Shot Taker (AI), Playmaker (AI)",
        "potential": [
            69,
            78,
            84,
            87,
            86,
            86,
            84
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            39.0,
            60.0,
            52.0,
            37.0,
            40.0,
            60.0
        ],
        "skill_2018": [
            60.0,
            63.0,
            69.0,
            40.0,
            53.0,
            67.0
        ],
        "skill_2019": [
            63.0,
            70.0,
            75.0,
            60.0,
            61.0,
            70.0
        ],
        "skill_2020": [
            66.0,
            75.0,
            79.0,
            64.0,
            67.0,
            70.0
        ],
        "skill_2021": [
            69.0,
            77.0,
            81.0,
            64.0,
            67.0,
            67.0
        ],
        "skill_2022": [
            72.0,
            79.0,
            82.0,
            66.0,
            67.0,
            64.0
        ],
        "skill_2023": [
            73.0,
            79.0,
            80.0,
            67.0,
            67.0,
            68.0
        ],
        "timeline": [
            {
                "club_name": "Borussia Mönchengladbach",
                "end_date": "2024-01-01",
                "start_date": "2019-01-01"
            },
            {
                "club_name": "Fortuna Düsseldorf",
                "end_date": "2019-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "1860 München",
                "end_date": "2018-01-01",
                "start_date": "2017-01-01"
            }
        ],
        "value_eur": [
            180000,
            1100000,
            6500000,
            15500000,
            35000000,
            43500000,
            29000000
        ],
        "wage_eur": [
            2000,
            6000,
            15000,
            27000,
            37000,
            36000,
            34000
        ]
    },
    {
        "age": 24,
        "evolutionImageURL": "plots/Aaron Wan-Bissaka.html",
        "long_name": "Aaron Wan-Bissaka",
        "overall": [
            57,
            56,
            55,
            72,
            80,
            83,
            83,
            79
        ],
        "player_face_url": "https://cdn.sofifa.net/players/229/880/23_120.png",
        "player_id": 231747,
        "player_positions": "RB",
        "player_tags": "",
        "player_traits": "Dives Into Tackles (AI)",
        "potential": [
            73,
            72,
            71,
            84,
            88,
            88,
            87,
            82
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            56.0,
            52.0,
            62.0,
            30.0,
            48.0,
            73.0
        ],
        "skill_2017": [
            48.0,
            50.0,
            61.0,
            28.0,
            48.0,
            77.0
        ],
        "skill_2018": [
            48.0,
            50.0,
            60.0,
            28.0,
            46.0,
            73.0
        ],
        "skill_2019": [
            47.0,
            60.0,
            68.0,
            72.0,
            66.0,
            84.0
        ],
        "skill_2020": [
            50.0,
            65.0,
            78.0,
            81.0,
            72.0,
            87.0
        ],
        "skill_2021": [
            51.0,
            68.0,
            80.0,
            81.0,
            74.0,
            86.0
        ],
        "skill_2022": [
            52.0,
            69.0,
            78.0,
            81.0,
            75.0,
            85.0
        ],
        "skill_2023": [
            50.0,
            65.0,
            73.0,
            77.0,
            70.0,
            82.0
        ],
        "timeline": [
            {
                "club_name": "Manchester United",
                "end_date": "2024-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Crystal Palace",
                "end_date": "2020-01-01",
                "start_date": "2016-01-01"
            }
        ],
        "value_eur": [
            220000,
            200000,
            170000,
            4900000,
            19500000,
            52000000,
            48500000,
            22000000
        ],
        "wage_eur": [
            2000,
            5000,
            4000,
            20000,
            76000,
            115000,
            115000,
            86000
        ]
    },
    {
        "age": 25,
        "evolutionImageURL": "plots/Tanguy Ndombèlé Alvaro.html",
        "long_name": "Tanguy Ndombèlé Alvaro",
        "overall": [
            61,
            74,
            79,
            81,
            80,
            82,
            79
        ],
        "player_face_url": "https://cdn.sofifa.net/players/235/569/23_120.png",
        "player_id": 231747,
        "player_positions": "CM, CDM, CAM",
        "player_tags": "#Dribbler",
        "player_traits": "Flair, Technical Dribbler (AI)",
        "potential": [
            75,
            85,
            88,
            89,
            87,
            87,
            82
        ],
        "skill_2015": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2016": [
            0,
            0,
            0,
            0,
            0
        ],
        "skill_2017": [
            54.0,
            64.0,
            66.0,
            56.0,
            55.0,
            75.0
        ],
        "skill_2018": [
            61.0,
            72.0,
            73.0,
            70.0,
            73.0,
            74.0
        ],
        "skill_2019": [
            66.0,
            76.0,
            85.0,
            70.0,
            78.0,
            80.0
        ],
        "skill_2020": [
            65.0,
            78.0,
            87.0,
            70.0,
            78.0,
            79.0
        ],
        "skill_2021": [
            66.0,
            80.0,
            87.0,
            69.0,
            72.0,
            74.0
        ],
        "skill_2022": [
            72.0,
            81.0,
            88.0,
            69.0,
            72.0,
            71.0
        ],
        "skill_2023": [
            71.0,
            79.0,
            86.0,
            68.0,
            68.0,
            66.0
        ],
        "timeline": [
            {
                "club_name": "Napoli",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "Tottenham Hotspur",
                "end_date": "2023-01-01",
                "start_date": "2020-01-01"
            },
            {
                "club_name": "Olympique Lyonnais",
                "end_date": "2020-01-01",
                "start_date": "2018-01-01"
            },
            {
                "club_name": "Amiens SC",
                "end_date": "2018-01-01",
                "start_date": "2017-01-01"
            }
        ],
        "value_eur": [
            425000,
            8500000,
            19000000,
            26000000,
            42000000,
            46000000,
            23000000
        ],
        "wage_eur": [
            1000,
            40000,
            50000,
            88000,
            82000,
            95000,
            85000
        ]
    },
    {
        "age": 27,
        "evolutionImageURL": "plots/Pierluigi Gollini.html",
        "long_name": "Pierluigi Gollini",
        "overall": [
            54,
            59,
            70,
            70,
            70,
            76,
            79,
            82,
            77
        ],
        "player_face_url": "https://cdn.sofifa.net/players/211/515/23_120.png",
        "player_id": 231747,
        "player_positions": "GK",
        "player_tags": "",
        "player_traits": "Rushes Out Of Goal, Comes For Crosses",
        "potential": [
            67,
            68,
            78,
            78,
            78,
            84,
            83,
            87,
            80
        ],
        "skill_2015": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2016": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2017": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2018": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2019": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2020": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2021": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2022": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "skill_2023": [
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0
        ],
        "timeline": [
            {
                "club_name": "Fiorentina",
                "end_date": "2024-01-01",
                "start_date": "2023-01-01"
            },
            {
                "club_name": "Tottenham Hotspur",
                "end_date": "2023-01-01",
                "start_date": "2022-01-01"
            },
            {
                "club_name": "Atalanta",
                "end_date": "2022-01-01",
                "start_date": "2017-01-01"
            },
            {
                "club_name": "Hellas Verona",
                "end_date": "2017-01-01",
                "start_date": "2015-01-01"
            }
        ],
        "value_eur": [
            70000,
            210000,
            1700000,
            2000000,
            2000000,
            8500000,
            19000000,
            35000000,
            10500000
        ],
        "wage_eur": [
            2000,
            2000,
            10000,
            10000,
            9000,
            28000,
            40000,
            48000,
            33000
        ]
    }
]