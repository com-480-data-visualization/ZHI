export const TabIntroduction = () => {

    return (
        <div>
            <h1>Introduction</h1>
            <p>This page will serve as an introduction to our project.  We will give a motivation of the project
                with storytelling (and some figures to determine later).
            </p>

        </div>
    )
}