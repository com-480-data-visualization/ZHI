import { useState } from 'react'
import { Player, players } from './players/player';
import LineChart  from './components/LineChart';
import RadarChart  from './components/RadarChart_old';
import TimelineChart from './components/TimelineChart_old'

import Button from '@mui/material/Button';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

export const TabPlayersEvolution = () => {

    const [displayOnePlayer, setDisplayOnePlayer] = useState(false);
    const [selectedPlayer, setSelectedPlayer] = useState<Player>();

    const OnePlayer = () => {

        return (
            <div style={{display: 'flex', flexDirection: 'column'}}>

                <Button variant="contained" startIcon={<ArrowBackIcon />} style ={{width:'80px'}} onClick={() => setDisplayOnePlayer(false)}>
                    Back
                </Button>

                <div style={{display: 'flex', flexDirection: 'row', marginBottom: '30px'}}>
                    <img src = {selectedPlayer?.faceImageURL} alt = {selectedPlayer?.firstName + ' ' + selectedPlayer?.lastName} style ={{marginTop:'10px', width:'100px', height:'100px'}}/>
                    <div style ={{marginLeft: '10px', fontWeight: 800}}> {selectedPlayer?.firstName + ' ' + selectedPlayer?.lastName}</div>
                </div>

                <div style = {{width: '100%'}}>
                    <LineChart />
                </div>

                <div style={{display: 'flex', flexDirection: 'row'}}>

                    <div style = {{width: '50%'}}>
                        <TimelineChart style = {{width: '60%'}}/>
                    </div>

                    <div style = {{width: '50%'}}>
                        <RadarChart style = {{width: '40%', borderRight: '1 px'}}/>
                    </div>
                </div>

            </div>
        )
    }

    const PlayerList = () => {

        const playerClicked = (player: Player) => {
            setDisplayOnePlayer(true);
            setSelectedPlayer(player);
        }

        return (
            <div>
                <h1>Players Evolution</h1>
                <p>We will briefly explain our approach here. </p>
                <br />
                <h3>Top 30 most-improved players</h3>

                <div style={{display: 'flex', flexDirection: 'row', flexWrap: 'wrap'}}>
                    {players.map( player => {
                        return (
                                <img src = {player.evolutionImageURL} alt = {player.firstName} onClick = {() => playerClicked(player)}  style = {{width: '33%'}}/>
                        )
                    })}
                </div>
            </div>
        )
    }
    
    return (
        displayOnePlayer? 
            <OnePlayer /> : <PlayerList />
    )
}