import React, { Component } from "react";
import { scaleThreshold, schemeBlues, geoCentroid } from 'd3';
import { geoMercator, geoPath } from 'd3-geo';
import countriesGeoData from '../players/countries.geo';
import {topDestinationCountries} from "../players/destinations"

let currentSelectedCountry =  "";
let destinationNames = [];
let countryColors = {};
countriesGeoData.features.map((feature, idx) => {
    countryColors[feature.properties.name] = 0.4 + Math.random() * 0.6;
});


const colorScale = scaleThreshold()
    .domain([100000, 1000000, 10000000, 30000000, 100000000, 500000000])
    .range(schemeBlues[7]);

class Map extends Component {
    constructor(props) {
        super(props)
        this.state = {mapSize: {width: 1200, height: 1200}, selectedCountry1: ""}
    }

    componentDidMount() {
        window.addEventListener("load", this.handleResize.bind(this));
        window.addEventListener("resize", this.handleResize.bind(this));
    }
    componentWillUnmount() {
        window.removeEventListener("load", this.handleResize);
        window.removeEventListener("resize", this.handleResize);
    }

    handleResize() {
        if (this.state.mapSize.height !== this.mapSVG.parentNode.clientHeight)
            this.setState({ ...this.state, mapSize: { ...this.state.mapSize, height: this.mapSVG.parentNode.clientHeight} })
        if (this.state.mapSize.width !== this.mapSVG.parentNode.clientWidth)
            this.setState({ ...this.state, mapSize: { ...this.state.mapSize, width: this.mapSVG.parentNode.clientWidth} })
    }

    render() {
        const { height, width } = this.state.mapSize;

        const projection = geoMercator()
            .scale(180)
            .center([0,0])
            .translate([width / 2, height / 2]);            

        const pathGenerator = geoPath().projection(projection);
        
        const setSelectedCountry = (name) => {               
           
            currentSelectedCountry = name;
            this.setState({ ...this.state, selectedCountry: name });
        }

        const countryLinks = getCountryLinks(currentSelectedCountry, pathGenerator, "red");

        const countries = countriesGeoData.features
            .map((feature, idx) => {
                return <path
                    key={idx}
                    d={pathGenerator(feature)}
                    style={{ stroke: "black", strokeWidth: 1, strokeOpacity: 1, cursor: "pointer" }}
                    fill= {getCountryColor(feature.properties.name)}
                    fillOpacity={getCountryOpacity(feature.properties.name)}
                    onMouseOver ={() => setSelectedCountry(feature.properties.name)}
                    onMouseLeave ={() => { setSelectedCountry("")}}
                    className="country"
            />})

      
        return (
            <div className='map' width={'100%'} height={'100%'}>
                <svg width={'100%'} height={'100%'} ref={(mapSVG) => this.mapSVG = mapSVG}>
                    {countries}
                    <g id="links">
                        {countryLinks}
                    </g>
                </svg>
            </div>
        )
    }
}

const getCountryLinks = (selectedCountry, pathGenerator, linkColor) => {

    let countryLinks = [];
    destinationNames = topDestinationCountries[selectedCountry] || [];

    const setSelectedCountry = (name) => {               
           
        currentSelectedCountry = name;
    }

    if (destinationNames.length > 0) {

        const sourceFeature = countriesGeoData.features.find(function(feature) {
            return feature.properties.name === selectedCountry;
          });

        const sourceCentroid = geoCentroid(sourceFeature);

        let idx = 0
        destinationNames.forEach( destinationName => {
            countriesGeoData.features.forEach (feature => {
               if (feature.properties.name === destinationName) {
                    const destCentroid = geoCentroid(feature);

                    const LineFeature = {            
                        "type": "Feature",
                        "geometry":{
                            type: 'LineString',
                            coordinates: [
                            [sourceCentroid[0], sourceCentroid[1]],
                            [destCentroid[0], destCentroid[1]]
                            ]
                        }
                    }            
                    
                    idx = idx + 1;

                    countryLinks.push(
                        <path
                            key={selectedCountry + '-' + destinationName + '.' + idx}
                            d={pathGenerator(LineFeature)}
                            style={{strokeWidth: 4, strokeOpacity: 1 }}
                            stroke= {linkColor}
                            fill = "none"
                            onMouseOver ={() => setSelectedCountry(selectedCountry)}
                            onMouseLeave ={() => { setSelectedCountry("")}}
                            className = "links"
                        />    
                    );
               }
            })
        });
    }
    return countryLinks;
}
const countriesToHighlight = [
    "Argentina",
    "Australia",
    "Belgium",
    "Colombia",
    "Croatia",
    "Denmark",
    "Ecuador",
    "England",
    "Finland",
    "France",
    "Germany",
    "Greece",
    "Hungary",
    "Italy",
    "Japan",
    "Mexico",
    "Netherlands",
    "Norway",
    "Poland",
    "Portugal",
    "Scotland",
    "Slovakia",
    "South Korea",
    "Spain",
    "Sweden",
    "Turkey",
    "USA"
];

const getCountryColor = (name) => {

    if (destinationNames.includes(name)) {
        return "orange"   
    } else if (countriesToHighlight.includes(name)) {
        return "green";
    } else {
        return colorScale(2000000);
    }
}


const getCountryOpacity = (name) => {

    if (countriesToHighlight.includes(name)) {
        return 1
    } else {
        return countryColors[name]; // 0.1 + Math.random() * 0.9;
    }
}

export default Map;