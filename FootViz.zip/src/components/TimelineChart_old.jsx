import * as React from 'react'
import ReactApexChart from 'react-apexcharts'

class TimelineChart extends React.Component {
    constructor(props) {
      super(props);

      this.state = {
      
        series: [
          {
            data: [
              {
                x: 'FC Barcelona',
                y: [
                  new Date('2015-01-01').getTime(),
                  new Date('2021-01-01').getTime()
                ]
              },{
              x: 'PSG',
              y: [
                new Date('2021-01-01').getTime(),
                new Date('2023-01-01').getTime()
              ]
            }, {
            x: 'Inter Miami',
            y: [
              new Date('2023-01-01').getTime(),
              new Date('2024-01-01').getTime()
            ]
           }
            ]
          }
        ],
        options: {
          chart: {
            height: 350,
            type: 'rangeBar',
            zoom: {
                enabled: false
              },
            toolbar: {
                tools:{
                  download:false 
                }
              }
          },
          title: {
            text: 'Transfers'
          },
          plotOptions: {
            bar: {
              horizontal: true
            }
          },
          xaxis: {
            type: 'datetime'
          }
        },
      
      
      };
    }

  

    render() {
      return (
        <div>
          <div id="chart">
            <ReactApexChart options={this.state.options} series={this.state.series} type="rangeBar" height={350} />
          </div>
          <div id="html-dist"></div>
        </div>
      );
    }
  }

  export default TimelineChart;