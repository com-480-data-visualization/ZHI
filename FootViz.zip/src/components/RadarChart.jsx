import * as React from 'react'
import ReactApexChart from 'react-apexcharts'

class RadarChart extends React.Component {
    constructor(props) {
      super(props);

      this.state = {
      
        series: [{
          name: 'Level',
          data: [80, 50, 30, 40, 100, 20],
        }],
        options: {
          chart: {
            height: 350,
            type: 'radar',
            toolbar: {
                show: true,
                tools:{
                  download:false 
                }
              }
          },
          title: {
            text: 'Skills'
          },
          yaxis: {
            stepSize: 20
          },
          xaxis: {
            categories: ['Shooting', 'Passing', 'Dribling', 'Defending', 'Physique', 'Pace']
          }
        },
      
      
      };
    }

  

    render() {
      return (
        <div>
          <div id="chart">
            <ReactApexChart options={this.state.options} series={this.state.series} type="radar" height={350} />
          </div>
          <div id="html-dist"></div>
        </div>
      );
    }
  }

  export default RadarChart;
