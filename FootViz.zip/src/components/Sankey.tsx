import { sankey, sankeyJustify, sankeyLinkHorizontal } from "d3-sankey";
import { useState } from "react";

const MARGIN_Y = 6;
const MARGIN_X = 1;

type Data = {
  nodes: { name: string; category: string; id: number }[];
  links: { source: string; target: string; value: number }[];
};

type SankeyProps = {
  width: number;
  height: number;
  data: any;
  colors: any
};

export const Sankey = ({ width, height, data, colors }: SankeyProps) => {

  // Set the sankey diagram properties
  const sankeyGenerator = sankey()
    .nodeWidth(15)
    .nodePadding(10)
    .extent([
      [MARGIN_X, MARGIN_Y],
      [width - MARGIN_X, height - MARGIN_Y],
    ])
    .nodeId((node: any) => node.id) // Accessor function: how to retrieve the id that defines each node. This id is then used for the source and target props of links
    .nodeAlign(sankeyJustify); // Algorithm used to decide node position

  // Compute nodes and links positions
  const { nodes, links } = sankeyGenerator(data);

  //
  // Draw the nodes
  //
  const allNodes = nodes.map((node: any) => {
    return (
      <g key={node.id}>
        <rect
          height={ (node.y1? node.y1: 0)  - (node.y0? node.y0 : 0) }
          width={sankeyGenerator.nodeWidth()}
          x={node.x0}
          y={node.y0}
          stroke={colors[node.category]}
          fill={colors[node.category]}
          fillOpacity={1}
          rx={0.9}
          onClick={() => setSrcNodeID(node.id)}
        />
      </g>
    );
  });

  //
  // Draw the links
  //
  const [srcNodeID, setSrcNodeID] = useState(-1);

  const allLinks = links.map((link: any, i: any) => {
    const linkGenerator = sankeyLinkHorizontal();
    const path = linkGenerator(link) +'';

    return (
      <path
        key={i}
        d={path}
        stroke={(link.source.id === srcNodeID)? colors[link.source.category]: "gray"}
        fill= {"none"}
        fillOpacity={(link.source.id === srcNodeID)? 0.8: 0.1}
        strokeOpacity={(link.source.id === srcNodeID)? 1: 0.1}
        strokeWidth={link.width}
        className="link"
        onClick={() => setSrcNodeID(link.source.id)}
      />
    );
  });

  //
  // Draw the Labels
  //
  const allLabels = nodes.map((node: any, i: any) => {
    return (
      <text
        key={i}
        x={node.x0 < width / 2 ? node.x1 + 6 : node.x0 - 6}
        y={(node.y1 + node.y0) / 2}
        dy="0.35rem"
        textAnchor={node.x0 < width / 2 ? "start" : "end"}
        fontSize={12}
        fontWeight={700}
      >
        {node.name}
      </text>
    );
  });

  return (
    <div>
      <svg width={width} height={height}>
        {allLinks}
        {allNodes}
        {allLabels}
      </svg>
    </div>
  );
};
