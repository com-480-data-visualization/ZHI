
export const TabIntroduction = () => {

    return (
        <div>
            <h1>Introduction</h1>

            <p>
            In one sentence, this project is our attempt to visualize the engaging dynamic between a football player’s career stages and the league he is playing for throughout his career.
            </p>

            <p>
            It's widely acknowledged that a footballer's choice of team is heavily influenced by the stage they're currently at in their career trajectory—be it the early, prime, or late stage before retirement. For example, a common pattern observed is that players often start in minor or smaller leagues, gradually making a name for themselves before eventually transitioning to larger clubs in major leagues. As they age and their competitive edge diminishes, many opt to retire with the team they have the deepest attachment to or sign with a club in a lesser-known league that offers handsome salaries. This is what we will attempt to make evident using the dataset at hand.
            </p>

            <p>
            This project is fascinating as it serves to provide newcomers to football with valuable context and insights into the sport. Moreover, it also verifies one of the common beliefs people have about football with real-life statistics and presents the results in vivid visualizations.
            </p>

            <p>
            For this project, we have utilized a comprehensive football player dataset from the FIFA console game. All data have been scrapped from the SoFIFA website.
            </p>

            <br/>
            <div style={{justifyContent: 'center', width: '100%', cursor: 'cross', pointerEvents: 'auto'}}>
                <img src = 'kaggle.jpg' width={800} height={450} style={{ marginLeft:'100px', cursor: 'hand', pointerEvents: 'auto'}} 
                onClick = {() => {window.open('https://www.kaggle.com/datasets/stefanoleone992/fifa-23-complete-player-dataset', '_blank')}}/>
            </div>
        </div>
    )
}


//            <iframe title='Introduction' src = '../flight_route_map.html' />
//<FrameWrapper html={'../flight_route_map.html'} />