import {useState} from 'react'

import { Sankey }  from "./components/Sankey"
import { players, colors } from "./players/player_sankey"
import Map from "./components/map"
import './App.css';
import team_categories from "./players/team_categories"

const rising_stars = team_categories.rising_stars;
const peak_players = team_categories.peak_players;
const falling_stars = team_categories.falling_stars;

let selectedTeamName= ""

const teamPlayersStyle = {
        position: 'absolute',
        overflow: 'visible',
        display: 'flex',
        flexDirection: 'column',
        minWidth: '200px',
        borderWidth: 2,
        borderColor: 'blue',
        borderRadius: 10,
        backgroundColor: '#99ccff', // '#D8D8D8',
        marginTop: 5,
        verticalAlign: 'text-top',
        textAlign: 'left',
        paddingRight: '10px'
}

export const TabTeamStrategies = () => {

    const [selectedTeamName, setSelectedTeamName] = useState("");

    const show_team_players = (team) => {

        return (
            <div style = {teamPlayersStyle}>
                {team.players.map(player => {
                    return (
                        <div style={{display: 'flex', flexDirection: 'row', marginBottom: 20 }} >
                            <img src = {player.player_face_url} alt = {player.player_face_url} width = {80} height = {80} style={{marginRight: 20,marginLeft: 10 }} />
                            <div style={{display: 'flex', flexDirection: 'column' }} >
                               <div style= {{height:20, fontWeight: 600, marginBottom: 5, fontWeight: 700 }}> {player.short_name}</div>
                               <div style= {{height:20, fontWeight: 600, marginBottom: 5 }}> Age: {player.age}</div>
                               <div style= {{height:20, fontWeight: 600, marginBottom: 5 }}> Year: {player.year}</div>
                               <div style= {{height:20, fontWeight: 600, marginBottom: 5 }}> Overall: {player.overall}</div>
                            </div>
                        </div>                    )
                })}
            </div>
        )
    }

    const team_view = (description, teams) => {
        
        return(
            <div style={{display: 'flex', flexDirection: 'column'}}>
            <h3 > {description} </h3>
            {
                teams.map(team => {

                    const showTeams = (selectedTeamName === team.team_name);

                    return (
                        <div style={{display: 'flex', flexDirection: 'row', marginBottom: 20 }} onMouseOver={()=> setSelectedTeamName(team.team_name)} onMouseOut={() => setSelectedTeamName("")}>
                            <img src = {team.team_url} alt = {team.team_name} width = {80} height = {80} style={{marginRight: 20,marginLeft: 10 }} />
                            <div style={{display: 'flex', flexDirection: 'column' }} >
                               <div style= {{height:20, fontWeight: 600, marginBottom: 5 }}> {team.team_name}</div>
                               <div style={{display: 'flex', flexDirection: 'row' , marginTop: 5, verticalAlign: 'text-top', textAlign: 'left'}} >
                                    <img src = {team.league_url} alt = {team.league_name} height = {15} style={{marginRight: 11, 
                                                                        objectFit: 'cover', overflow: 'hidden'}} />
                                    <div style= {{fontSize:11, height: 15}}> {team.league_name}</div>
                                </div>

                            </div>
                            {showTeams?
                                <div> {show_team_players(team)}</div>
                                :
                                null
                            }
                        </div>
                    )
                })
            }

        </div>        )
    }

    return (
        <div  height = {3000}>

            <h1>Transfer Categories</h1>
                <p>
                    Have you ever wondered why certain football clubs are known for developing young talent, others for buying the best players at their peak, and still others—often considered second-tier—for signing veteran players to enhance the club's image? This is because each club tailors its strategy based on the quality of its youth academy, its financial resources, and the competitiveness of the league in which it participates.
                </p>

                <p>
                    Here is a classification of clubs categorized by whether they are recognized for nurturing young talents, attracting the world's top players, or recruiting veteran players nearing the end of their careers.
                </p>
            <br />

            <div style={{marginLeft: '5%', width: '90%'}} >
                <div style={{display: 'flex', flexDirection: 'row', justifyContent:'space-between', width:'100%'}}>


                    {team_view("Produces rising stars", rising_stars)}
                    {team_view("Attracts peak players", peak_players)}
                    {team_view("Attracts falling stars", falling_stars)}

                </div>
            </div>

           <br />
           <p>
           This Sankey diagram shows the transfer between leagues at different career stages of 500 players from 2015 to 2023. 
            <ul>
                <li> League (early): is the league the player was playing in in 2015. </li>
                <li> League (mid): is the league the player played in for the longest time from 2016 to 2022. </li>
                <li> League (late): is the league the player was playing in in 2023.</li>
            </ul>
            </p>
           <br />

            <div width = {1200} height = {1000} backgroundColor="yellow">
              <Sankey data={players} width={1200} height={500} colors={colors}/>
              </div>

           <br />
           <p>To augment the information about transfers, below is an interactive map that shows you the top 5 most popular transfer destinations of players exiting from a country (one of those highlighted in green). </p>
           <br />
          
           <div width = {1200} height = {1000} backgroundColor="red">
             <Map selectedCountry = {""} />
            </div>

        </div>
   )
}

/*
           <Sankey data={players} width={960} height={500} colors={colors} />

<br />
           <p>We will briefly explain our approach here. 2 </p>
           <br />

           <FrameWrapper html={'../flight_route_map.html'} />
*/